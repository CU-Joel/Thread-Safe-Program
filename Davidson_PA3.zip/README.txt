To run: place multi-lookup.c, multi-lookup.h, util.c, util.h, and the files to be read from in the same folder.

$make

$./multi-lookup 1 1 serviced.txt results.txt names1.txt names2.txt names3.txt names4.txt names5.txt

//This is for 1 requestor and 1 resolver
